<?php return array(
    'IN' => 'भारत',
);
