<?php return array(
    'PK' => 'پکستان',
    'IN' => 'ਭਾਰਤ',
);
