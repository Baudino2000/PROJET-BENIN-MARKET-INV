<?php

\File::deleteDirectory(base_path('documentation/updates/'));
\File::deleteDirectory(storage_path('database/updates/'));
