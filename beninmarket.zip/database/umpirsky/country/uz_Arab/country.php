<?php return array(
    'UZ' => 'Ўзбекистон',
    'AF' => 'افغانستان',
);
