<?php return array(
    'AF' => 'Afgʼoniston',
    'UK' => 'Birlashgan Qirollik',
    'BR' => 'Braziliya',
    'FR' => 'Fransiya',
    'IN' => 'Hindiston',
    'IT' => 'Italiya',
    'DE' => 'Olmoniya',
    'UZ' => 'Oʼzbekiston',
    'US' => 'Qoʼshma Shtatlar',
    'RU' => 'Rossiya',
    'CN' => 'Xitoy',
    'JP' => 'Yaponiya',
);
